# Mold fungus detection > 2025-11-28 10:38am
https://universe.roboflow.com/cv-project-k4vv5/mold-fungus-detection-ple1y

Provided by a Roboflow user
License: CC BY 4.0

